
import java.util.*;

class Main {
  public static void main(String[] args) {
    double a, b, i;
    double sum=0, count=0;
    Scanner sc = new Scanner(System.in);

    System.out.print("Enter first number: ");
    a = sc.nextInt();

    System.out.print("Enter seconf number: ");
    b = sc.nextInt();

    for (i = a; i <= b; i++) {
      sum = sum + i;
      count++;
    }
    System.out.print("\nSum of all number:  "+sum);
    System.out.print("\nAverage: "+(sum/count));
    System.out.print("\nCount: "+count);

  }
}