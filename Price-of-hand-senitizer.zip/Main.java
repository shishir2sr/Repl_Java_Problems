import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.print("Enter your name: ");
    String name = sc.nextLine();
    
    
    System.out.print("\nEnter your money in hand: ");
    int moneyInHand = sc.nextInt();

    System.out.print("Price of Hand Sanitizer: ");
    int priceOfHandSanitizer = sc.nextInt();


    System.out.print("\nHello, "+name+"!");
    System.out.print("\nYou can purchase "+(moneyInHand/priceOfHandSanitizer)+" pack's of Hand sanitizer with the money you have. After buying hand sanitizer you will have remaining money of "+(moneyInHand%priceOfHandSanitizer));


  }
}