
import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.print("Enter name: ");
    String name = sc.nextLine();

    System.out.print("Number of Infected: ");
    int infected = sc.nextInt();

    System.out.print(""+name+" Needs,\n");
    

  
    if (infected >= 100) {
      System.out.println("60 days home quarantine + 2 months netflix subscription credit");
    } 
    else if (infected >= 50) {
      System.out.println("40 days home quarantine + 1 months netflix subscription credit");
    }
  else if (infected >= 10) {
      System.out.println("20 days home quarantine + 1 months netflix subscription credit");
    }

    else if (infected >= 3) {
      System.out.println("14 days home quarantine + no netflix subscription credit");
    }
  }
} 

